import React, { useState } from 'react';
import { Send, Leaf, Loader2 } from 'lucide-react';

// Simulated herb analysis response with a delay
const analyzeHerb = async (question: string): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // This is a simple simulation - in a real app, you'd connect to an actual AI service
  const responses: Record<string, string> = {
    'chamomile': 'Chamomile is known for its calming properties. It can help with sleep, anxiety, and digestive issues. It contains compounds like apigenin that promote relaxation.',
    'lavender': 'Lavender has both calming and antimicrobial properties. It\'s commonly used for stress relief, better sleep, and can help with minor burns and skin irritations.',
    'peppermint': 'Peppermint is excellent for digestive health. It can help with nausea, bloating, and IBS symptoms. It also has cooling properties and can help with headaches.',
    'default': 'This herb has various medicinal properties. For specific recommendations, please consult with a qualified healthcare practitioner.'
  };

  const matchedHerb = Object.keys(responses).find(herb => 
    question.toLowerCase().includes(herb)
  );

  return matchedHerb ? responses[matchedHerb] : responses.default;
};

function App() {
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState<Array<{type: 'question' | 'answer', text: string}>>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    setIsLoading(true);
    setChatHistory(prev => [...prev, { type: 'question', text: question }]);

    try {
      const answer = await analyzeHerb(question);
      setChatHistory(prev => [...prev, { type: 'answer', text: answer }]);
    } catch (error) {
      setChatHistory(prev => [...prev, { type: 'answer', text: 'Sorry, I encountered an error analyzing this herb.' }]);
    }

    setQuestion('');
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Leaf className="h-8 w-8 text-green-600 mr-2" />
            <h1 className="text-3xl font-bold text-gray-800">Herbal Wisdom AI</h1>
          </div>
          <p className="text-gray-600">Ask questions about herbs and their medicinal properties</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="h-[400px] overflow-y-auto mb-4 space-y-4">
            {chatHistory.length === 0 && (
              <div className="text-center text-gray-500 mt-8">
                Ask a question about any herb to get started!
              </div>
            )}
            {chatHistory.map((chat, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg ${
                  chat.type === 'question'
                    ? 'bg-green-50 ml-12'
                    : 'bg-gray-50 mr-12'
                }`}
              >
                <p className="text-gray-800">{chat.text}</p>
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="relative">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask about an herb (e.g., 'What are the benefits of chamomile?')"
              className="w-full p-4 pr-12 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-green-600 hover:text-green-700 disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="h-6 w-6 animate-spin" />
              ) : (
                <Send className="h-6 w-6" />
              )}
            </button>
          </form>
        </div>

        <div className="text-center text-sm text-gray-500">
          Note: This is a demonstration. For medical advice, please consult healthcare professionals.
        </div>
      </div>
    </div>
  );
}

export default App;